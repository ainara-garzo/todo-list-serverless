import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='agarzo',
    application_name='todo-list-serverless',
    app_uid='jYZyVbxMgSCHdTY43S',
    org_uid='af970569-13d3-495c-abd3-988be24ac5d0',
    deployment_uid='84f88907-476e-414d-922e-682400d36def',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.1.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
